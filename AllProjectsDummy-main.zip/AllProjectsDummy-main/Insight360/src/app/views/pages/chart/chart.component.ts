import { Component, OnInit, ChangeDetectorRef,Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import * as Highcharts from 'highcharts';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent {
  @Input() chartData1: any[];
  @Input() chartData2: any[];
  @Input() chartData3: any[];
  @Input() chartData4: any[];

  apiData3: never[];
  chartBarData3: any
  isLoading: boolean;



  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService,
    private _Activatedroute: ActivatedRoute) {
  }


  async ngOnInit() {
    await this.DashboardProjectData()
  }

  async DashboardProjectData() {
    this.isLoading = true;
    try {
      Highcharts.chart('container1', this.chartData1 as Highcharts.Options);
    
      this.isLoading = false;
    } catch (e: any) {
      // Error handling
    }
  }

}
