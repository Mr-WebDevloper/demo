import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-my-rating',
  templateUrl: './my-rating.component.html',
  styleUrls: ['./my-rating.component.scss'],
})
export class MyRatingComponent {
  isLoading: boolean = false;
  userList: any;
  firstName: any;
  lastName: any;
  mobileNo: any;
  user: any;
  rejectReason: string;
  userDepartmentList: any;
  mobile: any;
  employeeId: any;
  DOJ: string;
  reportingManager: string;
  selectedDepartment: any = '0';
  isManager: string;
  emailId: any;
  allManagerData: any;
  role: any;
  dataArray: any;
  chartData1: any;
  chartData2: any;
  chartData3: any;
  chartData4: any;

  dataArray1: any;
  dataArray2: any;
  dataArray3: any;
  dataArray4: any;
  userData: any = localStorage.getItem('userDetails');
  userDetails: any = JSON.parse(this.userData);
  departmentTabs: any = this.userDetails.Department.split(',');
  activeTab: number = 0;
  activeTabIndex: any;
  ratingData: any;
  prListDiv: boolean;
  selectedUser: any;
  allQue: any;
  ratingText: string[] = [
    '',
    'Strongly Disagree',
    'Disagree',
    'Neutral',
    'Agree',
    'Strongly Agree'
  ];
  groupDataForModal: any;
  dataArray5: any

  constructor(
    private utilservice: UtilService,
    private router: Router,
    private route: ActivatedRoute,
    private apiservice: ApiserviceService,
    public toasterService: ToasterService,
    private NgbModal: NgbModal
  ) { }
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();


  async ngOnInit(): Promise<void> {
    await this.myRating(0);

 
  }

  async myRating(index: any) {
    this.isLoading = true;
    this.activeTab = index;
    const tab = this.departmentTabs[index];
    try {
      let param = {
        userId: this.userDetails.UserID,
        department: tab,
        type: 'overAll',
      };

      const res = await this.apiservice.checkRating(param);
      const departmentData = await res.data.departmentData;
      const managerData = await res.data.managerData;
      const selfData = await res.data.selfData;
      const MMData = await res.data.MMData;
      const OverAllDeptData = res.data.overalldepartmentData

      const Array: any = [
        'Overall ',
        'Customer Management',
        'Personal Management',
        'Technical Knowledge',
      ];
      const options1 = {
        credits: {
          enabled: false,
        },
        title:false,
       
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },

        series: [
          {
            name: 'rating ',

            showInLegend: false,
            data: [
              parseFloat(departmentData.deptAvgCount),
              parseFloat(departmentData.deptCustomerServiceBehaviorCount),
              parseFloat(departmentData.deptPersonalManagementCount),
              parseFloat(departmentData.deptTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      const options2 = {
        credits: {
          enabled: false,
        },
        title:false,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        series: [
          {
            showInLegend: false,
            name: 'rating ',

            data: [
              parseFloat(managerData.managerAvgCount),
              parseFloat(managerData.managerCustomerServiceBehaviorCount),
              parseFloat(managerData.managerPersonalManagementCount),
              parseFloat(managerData.managerTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      const options3 = {
        credits: {
          enabled: false,
        },
        title:false,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        series: [
          {
            showInLegend: false,
            name: 'rating ',

            data: [
              parseFloat(selfData.selfRateCount),
              parseFloat(selfData.SelfCustomerServiceBehaviorCount),
              parseFloat(selfData.SelfPersonalManagementCount),
              parseFloat(selfData.SelfTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      if(this.userDetails.isManager == 1){
        const options4 = {
          credits: {
            enabled: false,
          },
          title:false,
          chart: {
            type: 'bar',
          },
          xAxis: {
            categories: Array,
            title: {
              text: 'Competency Summary',
              style: {
                fontWeight: 'bold',
                color: 'black',
              },
            },
          },
          yAxis: {
            title: {
              text: 'Rating Scale',
              style: {
                fontWeight: 'bold',
                color: 'black',
              },
            },
          },
          series: [
            {
              showInLegend: false,
              name: 'rating ',
  
              data: [
                parseFloat(MMData.MMAvgCount),
                parseFloat(MMData.MMCustomerServiceBehaviorCount),
                parseFloat(MMData.MMPersonalManagementCount),
                parseFloat(MMData.MMTechnicalKnowledgeBehaviorCount),
              ],
              marker: {
                enabled: false,
              },
            },
          ],
        };

      this.dataArray4 = options4;
      Highcharts.chart('container15-' + index, this.dataArray4 as Highcharts.Options);

      }
    

      const options5 = {
        credits: {
          enabled: false,
        },
        title:false,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        series: [{
          showInLegend: false,
          name: 'rating ',
          data: [parseFloat(OverAllDeptData.overalldeptAvgCount), parseFloat(OverAllDeptData.overalldeptCustomerServiceBehaviorCount), parseFloat(OverAllDeptData.overalldeptPersonalManagementCount), parseFloat(OverAllDeptData.overalldeptTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00'] // Green, Blue, Red, Yellow
        }],
      };

      this.dataArray1 = options1;
      this.dataArray2 = options2;
      this.dataArray3 = options3;
      this.dataArray5 = options5

      Highcharts.chart('container11-' + index, this.dataArray1 as Highcharts.Options);
      Highcharts.chart('container12-' + index, this.dataArray2 as Highcharts.Options);
      Highcharts.chart('container13-' + index, this.dataArray3 as Highcharts.Options);
      Highcharts.chart('container14-' + index, this.dataArray5 as Highcharts.Options);

      this.isLoading = false;
      await this.ratingList(this.userDetails.UserID)

    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }



  async ratingList(id:any) {
    this.isLoading = true;
    try {
      const res = await this.apiservice.getFeedbackGiven({userId: this.userDetails.UserID});
      this.ratingData = res.data.userList
      this.groupDataForModal = res.data.groupedData
      this.isLoading = false;
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }


  async openRemarkModal(content: TemplateRef<any>, u: any) {
    this.selectedUser = u.createdBy

    this.allQue = this.groupDataForModal.filter((group: any) => group.createdBy === this.selectedUser)[0].data;

    // this.isLoading = true;

    try {

      this.NgbModal.open(content, { backdrop: 'static', size: "xl" }).result.then((result: any) => {
      }).catch((res: any) => { });
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }

  }

}