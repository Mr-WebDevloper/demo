import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-team-list',
  templateUrl: './my-team-list.component.html',
  styleUrls: ['./my-team-list.component.scss']
})
export class MyTeamListComponent {
  isLoading:boolean=false;
  userList:any;
  firstName:any;
  lastName:any;
  mobileNo:any
  user: any;
  rejectReason: string;

  ratingText: string[] = [
    '',
    'Strongly Disagree',
    'Disagree',
    'Neutral',
    'Agree',
    'Strongly Agree'
  ];

  allQue: any;
  CustomerServiceBehavior: any;
  selectedUser: any;
  constructor(private utilservice: UtilService, private router: Router, private route: ActivatedRoute, private apiservice: ApiserviceService,  public toasterService:ToasterService,private NgbModal: NgbModal) { }
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  async ngOnInit(): Promise<void> {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
    }
    await this.getUsers();
  }
 
  async getUsers(){
    this.isLoading = true;
    try {
      const res = await this.apiservice.getMyTeamMember();
      this.userList = res.data.data
      this.isLoading = false;
      this.dtTrigger.next('');
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;

      // if (e.response.status == 401) {
      //   this.router.navigateByUrl('/login');
      // }
    }
  }

  async updateUser(){
    if (!this.firstName) {
      this.toasterService.showWarning("Please enter task", "");
      return;
    }
    if (!this.lastName) {
      this.toasterService.showWarning("Please enter description", "");
      return;
    }
    if (!this.mobileNo) {
      this.toasterService.showWarning("Please enter mobile no", "");
      return;
    }

    const validateMobileNO = await this.utilservice.IsMobileNumber(this.mobileNo);
    if (!validateMobileNO) {
      this.toasterService.showWarning("Please enter valid mobile no", "");
      return;
    }
    let param = {
      "userId":this.user.id,
      "firstName": this.firstName,
      "lastName":this.lastName,
      "mobileNo":this.mobileNo,
    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.updateUserDetails(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  
  }

  async deleteUser(){
    let param = {
      userId:this.user.id,
      remark:this.rejectReason
    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.deleteUser(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  
  }
  async openLgModalEdit(content: TemplateRef<any>, u: any) {
    this.user = u
    this.firstName = u.firstName
    this.lastName = u.lastName
    this.mobileNo = u.mobileNo
    this.NgbModal.open(content, { backdrop: 'static' }).result.then((result: any) => {
    }).catch((res: any) => { });
  }

  async opendeleteProjectModal(content: TemplateRef<any>, u: any){
    this.user = u
    this.rejectReason='';
    this.NgbModal.open(content, { backdrop: 'static' }).result.then((result: any) => {
    }).catch((res: any) => { });
  }

  async openRemarkModal(content: TemplateRef<any>, u: any){
    this.selectedUser = u
    this.isLoading = true;

    try {
      const res = await this.apiservice.isFeedbackGiven({userId:this.selectedUser.id});
      const isUser = res.data.data
      this.isLoading = false;
    if(isUser.length > 0){
      this.toasterService.showError("This user feedback already given","")
    }
    else{
      this.getQuestions()
      this.NgbModal.open(content, { backdrop: 'static',size:"xl" }).result.then((result: any) => {
      }).catch((res: any) => { });
    }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }

  
  }

  async addRemarks(){
    const arr1 = this.allQue[0];
    const arr2 = this.allQue[1];
    const arr3 = this.allQue[2];
    for(var i =0; i < arr1.data.length;i++){
      if(arr1.data[i].rating == 0 || arr1.data[i].remark == ''){
        this.toasterService.showWarning(`Please enter remark and rating for ${arr1.data[i].questions}`, "");
        return;
        break;
      }
    }

    for(var i =0; i < arr2.data.length;i++){
      if(arr2.data[i].rating == 0 || arr2.data[i].remark == ''){
        this.toasterService.showWarning(`Please enter remark and rating for ${arr2.data[i].questions}`, "");
        return;
        break;
      }
    }

    for(var i =0; i < arr3.data.length;i++){
      if(arr3.data[i].rating == 0 || arr3.data[i].remark == ''){
        this.toasterService.showWarning(`Please enter remark and rating for ${arr3.data[i].questions}`, "");
        return;
        break;
      }
    }
   
    let param = {
      answer:JSON.stringify(this.allQue),
      userId:this.selectedUser.id
    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.insertQueAnswer(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  rateQuestion(question: any, rating: number) {
    question.rating = rating;
  }

  async getQuestions(){
   
    this.isLoading = true;
    try {
      const res = await this.apiservice.getQuestions();
      this.allQue = res.data.data
      this.CustomerServiceBehavior = res.data.data;
      this.isLoading = false;
    
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  
  }

}
