import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-create-users',
  templateUrl: './create-users.component.html',
  styleUrls: ['./create-users.component.scss']
})
export class CreateUsersComponent {
  isLoading: boolean = false;
  DOJ:any
  firstName: any;
  lastName: any;
  passwordStr: any;
  inValidEmail: boolean = false;
  Cpassword: any;
  employeeId:any
  mobile: any;
  isManager:any = '-1';
  allManagerData: any;
  allDepartment: any;
  // selectedDepartment:any ="0";
  selectedDepartment: any= '0'
  reportingManager:any = '0';
  userDepartmentList:any = '0'
  emailId:any
  role:any = '0'
  constructor(private router: Router, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService) { }
  async ngOnInit() {
    await this.getUserData()
    await this.alldepartmentList()
  }
  async getUserData() {
   
    try {
      this.isLoading = true
      const res = await this.apiservice.getUsers();
      
      this.allManagerData = res.data.data.filter((x: any) =>  x.isManager == 1);
      this.isLoading = false
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login'); 
      }
    }
  }

  async createUser() {

    if (!this.firstName) {
      this.toasterService.showWarning("Please enter first name", "");
      return;
    }
    if (!this.lastName) {
      this.toasterService.showWarning("Please enter last name", "");
      return;
    }
    if (!this.emailId) {
      this.toasterService.showWarning("Please enter email id", "");
      return;
    }
    const validateEmail = await this.utilservice.validateEmailDomain(this.emailId);
    if (!validateEmail) {
      this.inValidEmail = true
      this.toasterService.showWarning("Please enter valid email id", "");
      return;
    }
    this.inValidEmail = false

    if(this.role == '0'){
      this.toasterService.showWarning("Please select role", "");
      return;
    }
    
    // if (!this.mobile) {
    //   this.toasterService.showWarning("Please enter mobile no", "");
    //   return;
    // }

    // const validateMobileNO = await this.utilservice.IsMobileNumber(this.mobile);
    // if (!validateMobileNO) {
    //   this.toasterService.showWarning("Please enter valid mobile no", "");
    //   return;
    // }

    if (!this.passwordStr) {
      this.toasterService.showWarning("Please enter password", "");
      return;
    }
    const validatePassword = await this.utilservice.validatePassword(this.passwordStr);
    if (!validatePassword) {
      this.toasterService.showWarning("Password field need minimum 8 characters in length and At least one uppercase and At least one lowercase and At least one digit and At least one special character", "");
      return;
    }
    
    if (!this.Cpassword) {
      this.toasterService.showWarning("Please enter confirm password", "");
      return;
    }
   
    if (this.passwordStr != this.Cpassword) {
      this.toasterService.showWarning("Password and Confirm Password should be same", "");
      return
    }
    if (!this.employeeId) {
      this.toasterService.showWarning("Please enter employee-Id", "");
      return;
    }
    if (!this.employeeId.startsWith('GE0')) {
      this.toasterService.showWarning("Please enter valid employee-Id EX.GE003", "");
      return;
    }
    if(this.DOJ == '0'){
      this.toasterService.showWarning("Please select date of joining", "");
      return;
    }
    if(this.reportingManager == '0'){
      this.toasterService.showWarning("Please select reporting manager", "");
      return;
    }
   
    if(this.selectedDepartment == "0"){
      this.toasterService.showWarning("Please select department", "");
      return;
    }
    if(this.isManager == '-1'){
      this.toasterService.showWarning("Please select is manager", "");
      return;
    }
    
   

    let param = {
      "firstName": this.firstName.trim(),
      "lastName":this.lastName.trim(),
      "Department": this.selectedDepartment,
      "joiningDate":this.DOJ,
      "Manager": this.reportingManager,
      "isManager":this.isManager,
      "password": this.passwordStr,
      "empId": this.employeeId,
      "emailId": this.emailId,
      "mobileNo":  '1234567890',
      "role" : this.role
    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.addUser(param);
      this.isLoading = false;

      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;

      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async alldepartmentList() {
    try {
      const res = await this.apiservice.getDepartments();
      this.userDepartmentList = res.data; // Assuming res.data is the array of departments
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    } finally {
      this.isLoading = false; // Assuming this variable is declared elsewhere
    }
  }
}
