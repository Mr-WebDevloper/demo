import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service'; 

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent {
  isLoading: boolean = false;
  userName: any;
  newPassword:any;
  confirmPassword:any;
  otp:any;
  inValidEmail: boolean = false;
  constructor(private utilservice: UtilService, private router: Router, private route: ActivatedRoute, private apiservice: ApiserviceService, public toasterService: ToasterService) { }

  ngOnInit(): void {
  }

  async resetUserPassword() {

    if (!this.userName) {
      // this.inValidEmail = true
      this.toasterService.showWarning("Please enter employee code", "");
      return;
    }
    // this.inValidEmail = false
    // const validateEmail = await this.utilservice.validateEmail(this.emailId);
    // if (!validateEmail) {
    //   this.inValidEmail = true
    //   this.toasterService.showWarning("Please enter valid email id", "");
    //   return;
    // }
    // this.inValidEmail = false

    if (!this.newPassword) {
      this.toasterService.showWarning("Please enter new password", "");
      return;
    }

    const validatePassword1 = await this.utilservice.validatePassword(this.newPassword);
    if (!validatePassword1) {
      this.toasterService.showWarning("In new password field need minimum 8 characters in length and At least one uppercase and At least one lowercase and At least one digit and At least one special character", "");
      return;
    }

    if (!this.confirmPassword) {
      this.toasterService.showWarning("Please enter confirm password", "");
      return;
    }

    if (this.newPassword != this.confirmPassword) {
      this.toasterService.showWarning("Password missmatch", "");
      return;
    }

    if (!this.otp) {
      this.toasterService.showWarning("Please enter otp", "");
      return;
    }
  
    let param = {
      empId: this.userName,
      newPassword: this.newPassword,
      confirmPassword: this.confirmPassword,
      otp: this.otp,
    }

    this.isLoading = true;
    try {
      const res = await this.apiservice.userResetPasswordRequest(param);
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message,"");
        this.router.navigate(['/login']);
        this.isLoading = false;
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "")
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async loginPage() {
    this.router.navigate(['/login']);
  }
}
