import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetManagerDetailsComponent } from './get-manager-details.component';

describe('GetManagerDetailsComponent', () => {
  let component: GetManagerDetailsComponent;
  let fixture: ComponentFixture<GetManagerDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetManagerDetailsComponent]
    });
    fixture = TestBed.createComponent(GetManagerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
