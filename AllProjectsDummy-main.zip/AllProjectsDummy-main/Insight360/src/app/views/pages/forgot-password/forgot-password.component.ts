import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent {
  isLoading: boolean = false;
  employeeId: any;
  inValidEmail: boolean = false;
  constructor(
    private utilservice: UtilService,
    private router: Router,
    private route: ActivatedRoute,
    private apiservice: ApiserviceService,
    public toasterService: ToasterService
  ) {}

  ngOnInit(): void {}

  async forgetPassword() {
    if (!this.employeeId) {
      this.toasterService.showWarning('Please enter employee code', '');
      return;
    }

    let param = {
      empId: this.employeeId,
    };

    this.isLoading = true;
    try {
      const res = await this.apiservice.userForgetPassword(param);
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, '');
        const userDetails = res.data.userDetails;
        this.isLoading = false;
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async loginPage() {
    this.router.navigate(['/login']);
  }
}
