import { Component, OnInit, ChangeDetectorRef,Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import * as Highcharts from 'highcharts';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-chart3',
  templateUrl: './chart3.component.html',
  styleUrls: ['./chart3.component.scss']
})
export class Chart3Component {
  @Input() chartData3: any[];

  apiData3: never[];
  chartBarData3: any
  isLoading: boolean;



  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService,
    private _Activatedroute: ActivatedRoute) {
  }


  async ngOnInit() {
    await this.DashboardProjectData()
  }

  async DashboardProjectData() {
    this.isLoading = true;
    try {
      Highcharts.chart('container3', this.chartData3 as Highcharts.Options);

     
      this.isLoading = false;
    } catch (e: any) {
      // Error handling
    }
  }

}
