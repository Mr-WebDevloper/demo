import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LogOutComponent } from './log-out/log-out.component';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { CreateUsersComponent } from './create-users/create-users.component';
import { UserListComponent } from './user-list/user-list.component';
import { MyTeamListComponent } from './my-team-list/my-team-list.component';
import { GetManagerDetailsComponent } from './get-manager-details/get-manager-details.component';
import { MyRatingComponent } from './my-rating/my-rating.component';

const routes: Routes = [
  { path: 'login',component: LoginComponent,},
  { path: 'logout',component: LogOutComponent,},
  { path: 'update-password',component: UpdatePasswordComponent,},
  { path: 'create-user',component: CreateUsersComponent,},
  { path: 'user-list',component: UserListComponent,},
  { path: 'my-team',component: MyTeamListComponent,},
  { path: 'manager-list',component: GetManagerDetailsComponent,},
  { path: 'my-rating',component: MyRatingComponent,},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {}
