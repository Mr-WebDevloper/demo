import { NgModule } from '@angular/core';
import { CommonModule,DatePipe } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PagesRoutingModule } from './pages-routing.module';
import { LoginComponent } from './login/login.component';
import { Page404Component } from './page404/page404.component';
import { Page500Component } from './page500/page500.component';
import { AccordionItemComponent, AccordionModule, ButtonModule, CardModule, FormModule, GridModule, NavModule, SharedModule, SpinnerModule, TabsModule, TooltipModule } from '@coreui/angular';
import { IconModule } from '@coreui/icons-angular';
import { LogOutComponent } from './log-out/log-out.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { ToastrModule } from 'ngx-toastr';
import { DataTablesModule } from 'angular-datatables';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import {MatStepperModule} from '@angular/material/stepper';
import { NgSelectModule } from '@ng-select/ng-select';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import { CreateUsersComponent } from './create-users/create-users.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

import { UserListComponent } from './user-list/user-list.component';
import { MyTeamListComponent } from './my-team-list/my-team-list.component';
import { MatIconModule } from '@angular/material/icon';
import { GetManagerDetailsComponent } from './get-manager-details/get-manager-details.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { ChartComponent } from './chart/chart.component';
import { Chart2Component } from './chart2/chart2.component';
import { Chart3Component } from './chart3/chart3.component';
import { Chart4Component } from './chart4/chart4.component';
import { MyRatingComponent } from './my-rating/my-rating.component';

@NgModule({
  declarations: [
    LoginComponent,
    Page404Component,
    Page500Component,
    LogOutComponent,
    UpdatePasswordComponent,
    CreateUsersComponent,
    ForgotPasswordComponent,
    UserListComponent,
    MyTeamListComponent,
    GetManagerDetailsComponent,
    ResetPasswordComponent,
    ChartComponent,
    Chart2Component,
    Chart3Component,
    Chart4Component,
    MyRatingComponent,
  ],
  imports: [
    MatIconModule,
    MatProgressSpinnerModule,
    SpinnerModule,
    CommonModule,
    PagesRoutingModule,
    CardModule,
    ButtonModule,
    MatTabsModule,
    MatTabsModule,
    GridModule,
    IconModule,
    FormModule,
    DataTablesModule,
    TooltipModule,
    FormsModule,
    ReactiveFormsModule,
    HighchartsChartModule,
    ToastrModule.forRoot({
      timeOut: 3000,
    }),
   
    MatStepperModule,
    NgSelectModule,
    FullCalendarModule,
    AccordionItemComponent,
    AccordionModule,
    SharedModule,
    NavModule,
    TabsModule
  ],
  providers: [
    DatePipe, 
    
  ],
})
export class PagesModule {
}
