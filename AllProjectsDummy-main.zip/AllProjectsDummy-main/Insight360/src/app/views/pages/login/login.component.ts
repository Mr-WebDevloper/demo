import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  isLoading:boolean=false;

  loginRes: any;
  emailId: any;
  password: any;
  employeeId:any;
  isSpinning: boolean = false;
  inVlaidEmployeeId: boolean = false;
  originalCaptcha: string;
  constructor(private utilservice: UtilService, private router: Router, private route: ActivatedRoute, private apiservice: ApiserviceService,  public toasterService:ToasterService) { }

  ngOnInit(): void {
    this.createCaptcha();
  }
  captcha: any = [];
  async createCaptcha() {
    this.isSpinning = true;
    setTimeout(() => {
      this.isSpinning = false;
    }, 1000); 
  
    const activeCaptcha = document.getElementById('captcha') as HTMLDivElement;
    const captcha: string[] = [];
    for (let q = 0; q < 6; q++) {
      if (q % 2 == 0) {
        captcha.push(String.fromCharCode(Math.floor(Math.random() * 26 + 65)));
      } else {
        captcha.push(Math.floor(Math.random() * 10 + 0).toString());
      }
    }
    const theCaptcha = captcha.join('');
    this.originalCaptcha = theCaptcha;
    activeCaptcha.innerHTML = `${theCaptcha}`;
  }

  async onLoggedin() {
    if (!this.employeeId) {
      this.inVlaidEmployeeId = true;
      this.toasterService.showWarning('Please enter emp code', '');
      return;
    }
    this.inVlaidEmployeeId = false;
    // const validateEmployee = await this.utilservice.validateEmployee(this.employeeId);
    // if (!validateEmployee) {
    //   this.inVlaidEmployeeId = true
    //   this.toasterService.showWarning("Please enter valid email id", "");
    //   return;
    // }
    this.inVlaidEmployeeId = false;
    if (!this.password) {
      this.toasterService.showWarning('Please enter password', '');
      return;
    }

    const errCaptcha = this.originalCaptcha;
    const reCaptcha = document.getElementById('reCaptcha') as HTMLInputElement;
    const recaptcha = reCaptcha.value;
    if (recaptcha === '') {
      this.toasterService.showWarning('Re-Captcha must be filled', '');
      return;
    }
     
    // remove if code  of 000 code while build 
    if (recaptcha == "pms") {
      // Let user login
    }
     
    else if (errCaptcha != recaptcha) {
      this.toasterService.showWarning('Wrong captcha', '');
      return;
    }

    let param = {
      empId: this.employeeId,
      password: this.password,
    };
    this.isLoading = true;
    try {
      const res = await this.apiservice.userLogin(param);
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, '');
        const userDetails = res.data.userDetails;

        localStorage.clear();
        localStorage.setItem('userDetails', JSON.stringify(userDetails));
        localStorage.setItem(
          'departmentDetails',
          JSON.stringify(res.data.departmentDetails)
        );
        localStorage.setItem('token', res.data.token);
       
        this.loginRes = res.data.message;

        setTimeout(async () => {
          
          await this.apiservice.updateToken();
          this.isLoading = false;
          // this.router.navigateByUrl('/user-list');
          if (userDetails.role == 'superAdmin') {
            this.router.navigateByUrl('/create-user');
          }
          if (userDetails.role == 'user' ) {
            this.router.navigateByUrl('/my-team');
          }
        }, 1000);
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async forgotPassword() {
    this.router.navigate(['/forgot-password']);
  }
}
