import { Component, OnInit, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as Highcharts from 'highcharts';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent {
  isLoading: boolean = false;
  userList: any;
  firstName: any;
  lastName: any;
  mobileNo: any
  user: any;
  rejectReason: string;
  userDepartmentList: any;
  mobile: any;
  employeeId: any;
  DOJ: string;
  reportingManager: string;
  selectedDepartment: any = '0'
  isManager: string;
  emailId: any;
  allManagerData: any;
  role: any
  dataArray: any
  chartData1: any;
  chartData2: any;
  chartData3: any;
  chartData4: any;

  dataArray1: any;
  dataArray2: any
  dataArray3: any
  dataArray4: any
  dataArray5:any

  userData: any = localStorage.getItem('userDetails');
  userDetails: any = JSON.parse(this.userData);
  departmentTabs: any
  activeTab: number = 0;
  ratingData: any;
  groupDataForModal: any;
  selectedUser: any;
  allQue: any;

  ratingText: string[] = [
    '',
    'Strongly Disagree',
    'Disagree',
    'Neutral',
    'Agree',
    'Strongly Agree'
  ];

  constructor(private cdr: ChangeDetectorRef, private utilservice: UtilService, private router: Router, private route: ActivatedRoute, private apiservice: ApiserviceService, public toasterService: ToasterService, private NgbModal: NgbModal) { }
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  async ngOnInit(): Promise<void> {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
    }
    await this.getUsers();
    await this.alldepartmentList()
  }

  async alldepartmentList() {
    try {
      const res = await this.apiservice.getDepartments();
      this.userDepartmentList = res.data; // Assuming res.data is the array of departments
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    } finally {
      this.isLoading = false; // Assuming this variable is declared elsewhere
    }
  }

  async getUsers() {
    this.isLoading = true;
    try {
      const res = await this.apiservice.getUsers();
      this.userList = res.data.data
      this.isLoading = false;
      this.dtTrigger.next('');
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;

      // if (e.response.status == 401) {
      //   this.router.navigateByUrl('/login');
      // }
    }
  }

  async updateUser() {
    if (!this.firstName) {
      this.toasterService.showWarning("Please enter first name", "");
      return;
    }
    if (!this.lastName) {
      this.toasterService.showWarning("Please enter last name", "");
      return;
    }

    // if (!this.mobileNo) {
    //   this.toasterService.showWarning("Please enter mobile no", "");
    //   return;
    // }

    // const validateMobileNO = await this.utilservice.IsMobileNumber(this.mobileNo);
    // if (!validateMobileNO) {
    //   this.toasterService.showWarning("Please enter valid mobile no", "");
    //   return;
    // }
    if(this.role == '0'){
      this.toasterService.showWarning("Please select role", "");
      return;
    }

    if (!this.employeeId) {
      this.toasterService.showWarning("Please enter employee-Id", "");
      return;
    }
    if (this.DOJ == '0') {
      this.toasterService.showWarning("Please select date of joining", "");
      return;
    }
    // if(this.reportingManager == '0'){
    //   this.toasterService.showWarning("Please select reporting manager", "");
    //   return;
    // }

    if (this.selectedDepartment == "0") {
      this.toasterService.showWarning("Please select department", "");
      return;
    }
    if (this.isManager == '-1') {
      this.toasterService.showWarning("Please select is manager", "");
      return;
    }


    let param = {
      "userId": this.user.id,
      "firstName": this.firstName,
      "lastName": this.lastName,
      "department": this.selectedDepartment,
      "manager": this.user.manager,
      "isManager": this.isManager,
      "empId": this.employeeId,
      "emailId": this.emailId,
      "mobileNo": '1234567890',
      "role": this.role

    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.updateUserDetails(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }

  }


  async openLgModalEdit(content: TemplateRef<any>, u: any) {
    this.user = u
    this.firstName = u.firstName
    this.lastName = u.lastName
    this.mobileNo = '1234567890'
    this.emailId = u.emailId
    this.employeeId = u.empId
    this.DOJ = u.joiningDate
    // this.reportingManager = u.manager
    this.isManager = u.isManager
    this.selectedDepartment = u.department.split(',');
    this.role = u.role

    this.NgbModal.open(content, { backdrop: 'static' }).result.then((result: any) => {
    }).catch((res: any) => { });
  }

  async openViewModal(content: TemplateRef<any>, u: any) {
    this.user = u
    this.selectedDepartment = '0'
    this.departmentTabs = await u.department.split(",")
    this.activeTab = 0;

    this.isLoading = true;
    try {

      let param = {
        "userId": this.user.id,
        "department": this.departmentTabs[0],
        "type": "userList"
      }
      const res = await this.apiservice.checkRating(param);
      const departmentData = res.data.departmentData;
      const managerData = res.data.managerData
      const selfData = res.data.selfData
      const MMData = res.data.MMData
      const OverAllDeptData = res.data.overalldepartmentData

      const Array: any = ["Overall ", "Customer Management", "Personal Management", "Technical Knowledge"];

      const options1 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {

          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },

        },
        series: [{
          showInLegend: false,
          name: 'rating ',

          data: [parseFloat(departmentData.deptAvgCount), parseFloat(departmentData.deptCustomerServiceBehaviorCount), parseFloat(departmentData.deptPersonalManagementCount), parseFloat(departmentData.deptTechnicalKnowledgeBehaviorCount)],
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00'],// Green, Blue, Red, Yellow
          marker: {
            enabled: false,
          },

        }],
      };

      const options2 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },

        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },

        },
        series: [{
          showInLegend: false,

          name: 'rating ',

          data: [parseFloat(managerData.managerAvgCount), parseFloat(managerData.managerCustomerServiceBehaviorCount), parseFloat(managerData.managerPersonalManagementCount), parseFloat(managerData.managerTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00']
        }],
      };

      const options3 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },

        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },

        },
        series: [{
          showInLegend: false,

          name: 'rating ',

          data: [parseFloat(selfData.selfRateCount), parseFloat(selfData.SelfCustomerServiceBehaviorCount), parseFloat(selfData.SelfPersonalManagementCount), parseFloat(selfData.SelfTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00']
        }],
      };

      const options4 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        series: [{
          showInLegend: false,
          name: 'rating ',
          data: [parseFloat(MMData.MMAvgCount), parseFloat(MMData.MMCustomerServiceBehaviorCount), parseFloat(MMData.MMPersonalManagementCount), parseFloat(MMData.MMTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00'] // Green, Blue, Red, Yellow
        }],
      };

      const options5 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        series: [{
          showInLegend: false,
          name: 'rating ',
          data: [parseFloat(OverAllDeptData.overalldeptAvgCount), parseFloat(OverAllDeptData.overalldeptCustomerServiceBehaviorCount), parseFloat(OverAllDeptData.overalldeptPersonalManagementCount), parseFloat(OverAllDeptData.overalldeptTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00'] // Green, Blue, Red, Yellow
        }],
      };

      this.dataArray1 = options1
      this.dataArray2 = options2
      this.dataArray3 = options3
      this.dataArray4 = options4
      this.dataArray5 = options5


      if (res.status) {
        this.NgbModal.open(content, { size: 'xl' }).result.then((result: any) => {
          Highcharts.chart('container11', this.dataArray1 as Highcharts.Options);
          Highcharts.chart('container12', this.dataArray2 as Highcharts.Options);
          Highcharts.chart('container13', this.dataArray3 as Highcharts.Options);
          Highcharts.chart('container14', this.dataArray5 as Highcharts.Options);
          Highcharts.chart('container15', this.dataArray4 as Highcharts.Options);
        }).catch((res: any) => { });
      }
      this.isLoading = false;
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");

      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
    await this.myRating(0)
  }

  async openRemarkModal(content: TemplateRef<any>, u: any) {
    this.user = u
    this.NgbModal.open(content, { backdrop: 'static' }).result.then((result: any) => {
    }).catch((res: any) => { });
  }


  async getUserData() {

    try {
      this.isLoading = true
      const res = await this.apiservice.getUsers();

      this.allManagerData = res.data.data.filter((x: any) => x.isManager == 1);
      this.isLoading = false
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }



  async myRating(index: any) {
    // this.isLoading = true;
    this.activeTab = index;
    const tab = this.departmentTabs[index];
    try {
      let param = {
        userId: this.user.id,
        department: tab,
        type: 'overAll',
      };

      const res = await this.apiservice.checkRating(param);
      const departmentData = await res.data.departmentData;
      const managerData = await res.data.managerData;
      const selfData = await res.data.selfData;
      const MMData = await res.data.MMData;
      const OverAllDeptData = res.data.overalldepartmentData
      const Array: any = [
        'Overall ',
        'Customer Management',
        'Personal Management',
        'Technical Knowledge',
      ];
      const options1 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },

        series: [
          {
            name: 'rating ',

            showInLegend: false,
            data: [
              parseFloat(departmentData.deptAvgCount),
              parseFloat(departmentData.deptCustomerServiceBehaviorCount),
              parseFloat(departmentData.deptPersonalManagementCount),
              parseFloat(departmentData.deptTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      const options2 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        series: [
          {
            showInLegend: false,
            name: 'rating ',

            data: [
              parseFloat(managerData.managerAvgCount),
              parseFloat(managerData.managerCustomerServiceBehaviorCount),
              parseFloat(managerData.managerPersonalManagementCount),
              parseFloat(managerData.managerTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      const options3 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: 'black',
            },
          },
        },
        series: [
          {
            showInLegend: false,
            name: 'rating ',

            data: [
              parseFloat(selfData.selfRateCount),
              parseFloat(selfData.SelfCustomerServiceBehaviorCount),
              parseFloat(selfData.SelfPersonalManagementCount),
              parseFloat(selfData.SelfTechnicalKnowledgeBehaviorCount),
            ],
            marker: {
              enabled: false,
            },
          },
        ],
      };

      if(this.user.isManager == 1){
        const options4 = {
          credits: {
            enabled: false,
          },
          title: null,
          chart: {
            type: 'bar',
          },
          xAxis: {
            categories: Array,
            title: {
              text: 'Competency Summary',
              style: {
                fontWeight: 'bold',
                color: 'black',
              },
            },
          },
          yAxis: {
            title: {
              text: 'Rating Scale',
              style: {
                fontWeight: 'bold',
                color: 'black',
              },
            },
          },
          series: [
            {
              showInLegend: false,
              name: 'rating ',
  
              data: [
                parseFloat(MMData.MMAvgCount),
                parseFloat(MMData.MMCustomerServiceBehaviorCount),
                parseFloat(MMData.MMPersonalManagementCount),
                parseFloat(MMData.MMTechnicalKnowledgeBehaviorCount),
              ],
              marker: {
                enabled: false,
              },
            },
          ],
        };

        this.dataArray4 = options4;
        Highcharts.chart('container15-' + index, this.dataArray4 as Highcharts.Options);

      }
      const options5 = {
        credits: {
          enabled: false,
        },
        title: null,
        chart: {
          type: 'bar',
        },
        xAxis: {
          categories: Array,
          title: {
            text: 'Competency Summary',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        yAxis: {
          title: {
            text: 'Rating Scale',
            style: {
              fontWeight: 'bold',
              color: "black"
            }
          },
        },
        series: [{
          showInLegend: false,
          name: 'rating ',
          data: [parseFloat(OverAllDeptData.overalldeptAvgCount), parseFloat(OverAllDeptData.overalldeptCustomerServiceBehaviorCount), parseFloat(OverAllDeptData.overalldeptPersonalManagementCount), parseFloat(OverAllDeptData.overalldeptTechnicalKnowledgeBehaviorCount)],
          marker: {
            enabled: false,
          },
          colors: ['#00FF00', '#0000FF', '#FF0000', '#FFFF00'] // Green, Blue, Red, Yellow
        }],
      };

      this.dataArray1 = options1;
      this.dataArray2 = options2;
      this.dataArray3 = options3;
      this.dataArray5 = options5;

      Highcharts.chart('container11-' + index, this.dataArray1 as Highcharts.Options);
      Highcharts.chart('container12-' + index, this.dataArray2 as Highcharts.Options);
      Highcharts.chart('container13-' + index, this.dataArray3 as Highcharts.Options);
      Highcharts.chart('container14-' + index, this.dataArray5 as Highcharts.Options);
      await this.ratingList(this.user.id)

      this.isLoading = false;
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }



  async ratingList(id:any) {
    this.isLoading = true;
    try {
      const res = await this.apiservice.getFeedbackGiven({userId:id});
      this.ratingData = res.data.userList
      this.groupDataForModal = res.data.groupedData

      this.isLoading = false;
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, '');
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async openRemarksModal(content: TemplateRef<any>, u: any) {
    this.selectedUser = u.createdBy

    this.allQue = this.groupDataForModal.filter((group: any) => group.createdBy === this.selectedUser)[0].data;

    // this.isLoading = true;

    try {

      this.NgbModal.open(content, { backdrop: 'static', size: "xl" }).result.then((result: any) => {
      }).catch((res: any) => { });
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }

  }
}




