import { Injectable } from '@angular/core';
import axios from 'axios';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  API = axios.create({
    baseURL: environment.baseUrl,
    withCredentials: true,
    headers: {
      'Authorization': localStorage.getItem('token') ? `Bearer ${localStorage.getItem('token')}` : '',
    }
  })
  constructor() { }

  async updateToken() {
    this.API = axios.create({
      baseURL: environment.baseUrl,
      headers: {
        Authorization: localStorage.getItem("token")
          ? `Bearer ${localStorage.getItem("token")}`
          : "",
        "Access-Control-Allow-Credentials": true,
      },
    });
  }
  
async userLogin(param: any) {
    return await this.API.post('/api/login', param);
  }
async updatePassword(param: any) {
    return await this.API.post('/api/resetPassword', param);
}

async updateUsersPassword(param:any){
  return await this.API.post('/api/auth/resetPassword',param)
}
async addUser(param:any){
  return await this.API.post('/api/create-user',param)
}
async getUsers(){
  return await this.API.get('/api/getAllUsers')
}
async getMyTeamMember(){
  return await this.API.get('/api/getMyTeamMember')

}
async getQuestions(){
  return await this.API.get('/api/getQuestions')
 
}
async insertQueAnswer(param:any){
  return await this.API.post('/api/insertQuestionAnswer',param)
}
async updateUserDetails(param:any){
  return await this.API.post('/api/updateUserData',param)
}
async deleteUser(param:any){
  return await this.API.put('/api/user/deleteUser',param)
}

async getDepartments(){
  return await this.API.get('/api/getDepartment')
}

async isFeedbackGiven(param:any){
  return await this.API.post('/api/isFeedbackGiven',param)
}

async getManagerDetails(){
  return await this.API.get('/api/getManagerDetails')

}

async userForgetPassword(param:any){
  return await this.API.post('/api/userForgetPassword',param)

}

async userResetPasswordRequest(param: any){
  return await this.API.post('/api/userResetPasswordRequest', param);
}

async checkRating(param:any){
  return await this.API.post('/api/checkRating', param);

}

async getFeedbackGiven(param:any){
  return await this.API.post('/api/getFeedbackGiven',param);
}
}