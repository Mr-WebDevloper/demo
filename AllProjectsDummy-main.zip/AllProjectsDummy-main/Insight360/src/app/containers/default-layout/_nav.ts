import { INavData } from '@coreui/angular';

export const UserAsManagerItems: INavData[] = [
  {
    name: 'User',
  },
  
  {
    name: 'My Team',
    url: '/my-team',
    iconComponent: { name: 'cilGroup' }
  },
 
  {
    name: 'Manager list',
    url: '/manager-list',
    iconComponent: { name: 'cilLibraryAdd' }
  },

   {
    name: 'Overall Rating',
    url: '/my-rating',
    iconComponent: { name: 'cilStar' }
  },
];



export const UserItems: INavData[] = [
  {
    name: 'User',
  },
  
  {
    name: 'My Team',
    url: '/my-team',
    iconComponent: { name: 'cilGroup' }
  },

   {
    name: 'Overall Rating',
    url: '/my-rating',
    iconComponent: { name: 'cilStar' }
  },
];


export const SuperAdminItems: INavData[] = [
  {
    name: 'Super Admin',
  },
  {
    name: 'Create User',
    url: '/create-user',
    iconComponent: { name: 'cilUserFollow' }
  },
  {
    name: 'User List',
    url: '/user-list',
    iconComponent: { name: 'cilUser' }
  },
  
  {
    name: 'My Team',
    url: '/my-team',
    iconComponent: { name: 'cilGroup' }
  },
 
  {
    name: 'Manager List',
    url: '/manager-list',
    iconComponent: { name: 'cilLibraryAdd' }
  },

  {
    name: 'Overall Rating',
    url: '/my-rating',
    iconComponent: { name: 'cilStar' }
  },
];



