export const environment = {
    production: false,
    // baseUrl:"https://insight360-api.gegadyne.com"
    baseUrl:"http://192.168.100.27:3002"
};
    