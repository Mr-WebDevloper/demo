export const environment = {
    production: true,
    baseUrl:"http://192.168.100.27:3002"
      // baseUrl:"https://insight360-api.gegadyne.com"
};
