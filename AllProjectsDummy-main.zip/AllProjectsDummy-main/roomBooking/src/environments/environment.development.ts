export const environment = {
    production: true,
    // baseUrl:"http://192.168.100.150:3000"
      // baseUrl:"http://172.16.16.4:3002"
     //baseUrl:"http://192.168.100.45:3001"
    baseUrl:"https://meetings-api.gegadyne.com"

};
