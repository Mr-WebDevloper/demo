export const environment = {
    production: false,
    //baseUrl:"http://192.168.100.150:3000"
    // baseUrl: "http://172.16.16.4:3002"
    baseUrl:"https://meetings-api.gegadyne.com"
    
};
