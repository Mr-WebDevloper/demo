import { INavData } from '@coreui/angular';

export const UserItems: INavData[] = [
  {
    name: 'User',
  },
  {
    name: 'Meeting Reservation',
    url: '/assign-rooms',
    iconComponent: { name: 'cil-list' }
  },
  {
    name: 'My Meetings',
    url: '/my-meetings',
    iconComponent: { name: 'cil-list' }
  },
];

export const SuperAdminItems: INavData[] = [
  {
    name: 'Super Admin',
  },
  {
    name: 'Create Room',
    url: '/create-room',
    iconComponent: { name: 'cil-pencil' }
  },
  {
    name: 'Create User',
    url: '/create-user',
    iconComponent: { name: 'cil-pencil' }
  },
  {
    name: 'Update User',
    url: '/update-user',
    iconComponent: { name: 'cil-list' }
  },
  // {
  //   name: 'Meeting Reservation',
  //   url: '/assign-rooms',
  //   iconComponent: { name: 'cil-list' }
  // },
  // {
  //   name: ' My Meetings',
  //   url: '/my-meetings',
  //   iconComponent: { name: 'cil-list' }
  // },
  {
    name: 'Reservation Details',
    url: '/all-meetings',
    iconComponent: { name: 'cil-list' }
  },
];



