import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-get-all-my-meetings',
  templateUrl: './get-all-my-meetings.component.html',
  styleUrls: ['./get-all-my-meetings.component.scss']
})
export class GetAllMyMeetingsComponent {
  isLoading:boolean=false;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  allMeetings: any;
  feedback: any;
  SuggestionsforImprovement: any;
  selectedBooking: any;
  selectedMeeting: any;
  allparticipants: any;
  isUser:any=false
  userData: any = localStorage.getItem('userDetails');
  userDetails: any = JSON.parse(this.userData);

  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService) {
    
  }

  async ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
    }

    await this.getUserData();
    console.log(this.userDetails)
    
  }

  async getUserData() {
    
    this.isLoading = true
    try {
      const res = await this.apiservice.getUserMeetings();
      this.allMeetings = res.data.data;
    this.isLoading = false
      this.dtTrigger.next('');
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message,"");
    this.isLoading = false
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

 async deleteMeetingData(m: any) {
this.isLoading = true
  try {
    const res = await this.apiservice.deleteMeeting({ bookingId: m.id});
    this.isLoading = false
    if (res.data.status) {
      this.toasterService.showSuccess(res.data.message, "");
      window.location.reload();
    }
  } catch (e: any) {
    this.toasterService.showError(e.response.data.message, "");
  this.isLoading = false
    if (e.response.status == 401) {
      this.router.navigateByUrl('/login');
    }
  }

 }

 async openLgModal(content: TemplateRef<any>, b: any) {
  this.selectedBooking=b
  this.NgbModal.open(content, { size: 'lg' }).result.then((result: any) => {
  }).catch((res: any) => { });
}

async viewParticipantModal(content: TemplateRef<any>, meeting: any) {
  this.selectedMeeting=meeting
  const res = await this.apiservice.getparticipantsByMeetingId({ meetingId: meeting.id});
  this.allparticipants = res.data.data;
  this.NgbModal.open(content, { size: 'lg' }).result.then((result: any) => {
   
  }).catch((res: any) => { });
}

async AddFeedback() {
  if (!this.SuggestionsforImprovement) {
    this.toasterService.showWarning("Suggestions for Improvement", "");
    return;
  }

  if (!this.feedback) {
    this.toasterService.showWarning("Please enter feedback", "");
    return;
  }



 

  let param = {
    "bookingId": this.selectedBooking.id,
    "suggestion": this.SuggestionsforImprovement,
    "additionalComments":this.feedback
  }

  this.isLoading = true;


  try {
    const res = await this.apiservice.addSuggetion(param);
  this.isLoading = false
    if (res.data.status) {
      this.toasterService.showSuccess(res.data.message, "");
      window.location.reload();
    }
  } catch (e: any) {
    this.toasterService.showError(e.response.data.message, "");
  this.isLoading = false
    if (e.response.status == 401) {
      this.router.navigateByUrl('/login');
    }
  }
}


async deleteMeetingParticipant(p:any){
  this.isLoading = true
  try {
    let param = {
      "meetingId": this.selectedMeeting.id,
      "userId": p.id
    }
   
    const res = await this.apiservice.deleteMeetingParticipant(param);
    this.isLoading = false
    if (res.data.status) {
      this.toasterService.showSuccess(res.data.message, "");
      window.location.reload();
    }
  } catch (e: any) {
    this.toasterService.showError(e.response.data.message, "");
  this.isLoading = false
    if (e.response.status == 401) {
      this.router.navigateByUrl('/login');
    }
  }
}

}
