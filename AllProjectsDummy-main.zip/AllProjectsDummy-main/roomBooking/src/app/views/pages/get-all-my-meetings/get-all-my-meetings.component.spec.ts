import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllMyMeetingsComponent } from './get-all-my-meetings.component';

describe('GetAllMyMeetingsComponent', () => {
  let component: GetAllMyMeetingsComponent;
  let fixture: ComponentFixture<GetAllMyMeetingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetAllMyMeetingsComponent]
    });
    fixture = TestBed.createComponent(GetAllMyMeetingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
