import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-create-room',
  templateUrl: './create-room.component.html',
  styleUrls: ['./create-room.component.scss']
})
export class CreateRoomComponent {
  image_FileList: any = [];
  isLoading: boolean = false;
  roomName: any;
  allRoom: any;
  selectedDept: any;
  selectedRoom: any;
  floor: any = '0'
  seatingCapacity: any;
  roomDetails: any;
  meetingType: any = '0'

  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService) {

  }
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      //   lengthMenu: [
      //     [5, 10, 25, 50, -1 ],
      //     [ '5 rows','10 rows', '25 rows', '50 rows', 'Show all' ]
      // ],
    }
    this.getRoomsData()
  }

  async getRoomsData() {
    this.isLoading = true;
    try {
      const res = await this.apiservice.getRooms();
      this.allRoom = res.data.data;
      this.isLoading = false;
      this.dtTrigger.next('');
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }
  async addRoom() {
    if (!this.roomName) {
      this.toasterService.showWarning("Please enter meeting room name", "");
      return;
    }
   
    if (!this.floor || this.floor == 0) {
      this.toasterService.showWarning("Please select floor", "");
      return;
    }

    if (!this.seatingCapacity) {
      this.toasterService.showWarning("Please enter seating capacity", "");
      return;
    }

    if (!this.roomDetails) {
      this.toasterService.showWarning("Please enter room details", "");
      return;
    }

    if (!this.meetingType || this.meetingType == 0) {
      this.toasterService.showWarning("Please enter meeting type ", "");
      return;
    }

    this.isLoading = true;

    try {

      let param={
        name:this.roomName,
        floor:this.floor,
        seatingCapacity:this.seatingCapacity,
        roomDetails:this.roomDetails,
        meetingType:this.meetingType
      }
   
      const res = await this.apiservice.addRoom(param);
      this.isLoading = false;

      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;

      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }
  async updateRoom() {
    if (!this.roomName) {
      this.toasterService.showWarning("Please enter meeting room name", "");
      return;
    }
    if (!this.floor || this.floor == 0) {
      this.toasterService.showWarning("Please select floor", "");
      return;
    }
   
    if (!this.seatingCapacity) {
      this.toasterService.showWarning("Please enter seating capacity", "");
      return;
    }

    if (!this.roomDetails) {
      this.toasterService.showWarning("Please enter room details", "");
      return;
    }
    if (this.meetingType==0) {
      this.toasterService.showWarning("Please enter meeting type ", "");
      return;
    }
    this.isLoading = true;

    let param={
      name:this.roomName,
      floor:this.floor,
      seatingCapacity:this.seatingCapacity,
      roomDetails:this.roomDetails,
      meetingType:this.meetingType,
      id:this.selectedRoom.id,
      isActive: this.selectedRoom.isActive,
    }
   
    this.isLoading = true;

    try {
      const res = await this.apiservice.updateRoom(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async deleteRoom(d: any) {

    let param={
      name:d.name,
      floor:d.floor,
      seatingCapacity:d.seatingcapacity,
      roomDetails:d.roomDetails,
      meetingType:d.meetingType,
      id:d.id,
      isActive: 0,
    }

    
    this.isLoading = true;

    try {
      const res = await this.apiservice.updateRoom(param);
      this.isLoading = false;
      if (res.data.status) {
        this.toasterService.showSuccess('room deleted succesfully', "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async openLgModalAdd(content: TemplateRef<any>, d: any) {
    this.selectedRoom = d
    this.roomName = d.name
    this.floor = d.floor
    this.seatingCapacity = d.seatingcapacity
    this.roomDetails = d.roomDetails
    this.meetingType = d.meetingType

    this.NgbModal.open(content, { backdrop: 'static' }).result.then((result: any) => {
      this.roomName = ''
      this.floor = ''
      this.seatingCapacity = ''
      this.roomDetails = ''
      this.meetingType = ''
    }).catch((res: any) => { });

  }

  getImages(event: any) {
    this.image_FileList = event.target.files;
  }

}
