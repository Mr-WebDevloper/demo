import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LogOutComponent } from './log-out/log-out.component';
import { UpdatePasswordComponent } from './update-password/update-password.component';
import { CreateRoomComponent } from './create-room/create-room.component';
import { CreateUsersComponent } from './create-users/create-users.component';
import { UpdateUsersComponent } from './update-users/update-users.component';
import { AssignRoomsComponent } from './assign-rooms/assign-rooms.component';
import { GetAllMeetingsComponent } from './get-all-meetings/get-all-meetings.component';
import { GetAllMyMeetingsComponent } from './get-all-my-meetings/get-all-my-meetings.component';


const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Login Page'
    }
  },
  {
    path: 'logout',
    component: LogOutComponent,
    data: {
      title: 'Logout Page'
    }
  },
  {
    path: 'update-password',
    component: UpdatePasswordComponent,
    data: {
      title: 'Update Password'
    }
  },
  {
    path: 'create-room',
    component: CreateRoomComponent,
   
  },
  {
    path: 'create-user',
    component: CreateUsersComponent,
   
  },
  
  {
    path: 'update-user',
    component: UpdateUsersComponent,
   
  },
  {
    path: 'assign-rooms',
    component: AssignRoomsComponent,
   
  },
  {
    path: 'all-meetings',
    component: GetAllMeetingsComponent,
   
  },
  {
    path: 'my-meetings',
    component: GetAllMyMeetingsComponent,
  },
  
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule {
}
