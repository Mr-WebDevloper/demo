import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-get-all-meetings',
  templateUrl: './get-all-meetings.component.html',
  styleUrls: ['./get-all-meetings.component.scss']
})
export class GetAllMeetingsComponent {
  isLoading:boolean=false;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();

  selectedUser: any;
  allMeetings: any;
  selectedMeeting: any;
  allparticipants: any;



  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService) {
  }

  async ngOnInit() {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
    }

    await this.getMeetingData();
  }

  async getMeetingData() {
    this.isLoading = true
    try {
      const res = await this.apiservice.getAllMeetings();
      this.allMeetings = res.data.data;
    this.isLoading = false
      this.dtTrigger.next('');
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message,"");
    this.isLoading = false
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

 
  async viewParticipantModal(content: TemplateRef<any>, meeting: any) {
    this.selectedMeeting=meeting
    const res = await this.apiservice.getparticipantsByMeetingId({ meetingId: meeting.id});
    this.allparticipants = res.data.data;
    this.NgbModal.open(content, { size: 'lg' }).result.then((result: any) => {
    }).catch((res: any) => { });
  }
}
