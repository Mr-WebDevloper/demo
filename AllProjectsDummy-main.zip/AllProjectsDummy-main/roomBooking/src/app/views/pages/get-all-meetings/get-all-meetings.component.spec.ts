import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllMeetingsComponent } from './get-all-meetings.component';

describe('GetAllMeetingsComponent', () => {
  let component: GetAllMeetingsComponent;
  let fixture: ComponentFixture<GetAllMeetingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetAllMeetingsComponent]
    });
    fixture = TestBed.createComponent(GetAllMeetingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
