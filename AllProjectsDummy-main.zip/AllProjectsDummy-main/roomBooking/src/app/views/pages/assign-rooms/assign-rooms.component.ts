import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiserviceService } from 'src/app/services/apiservice.service';
import { UtilService } from 'src/app/services/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';

@Component({
  selector: 'app-assign-rooms',
  templateUrl: './assign-rooms.component.html',
  styleUrls: ['./assign-rooms.component.scss']
})
export class AssignRoomsComponent {
  isLoading: boolean;
  roomsList: any;
  roomName: any = '0'
  date: any;
  startTime: any;
  endTime: any;
  minDate: any;
  meetingType: any = '0'
  participant: any;
  outSidePerson: any
  seatingcapacity: any = 0;
  floor: any
  roomDetails: any;
  roomsListData: any;
  allUserData: any;
  showError: boolean;
  userData: any
  userDetails: any;
  purpose:any='0'

  constructor(private router: Router, private NgbModal: NgbModal, private utilservice: UtilService, private apiservice: ApiserviceService, public toasterService: ToasterService) {
    this.userData = localStorage.getItem('userDetails');
    this.userDetails= JSON.parse(this.userData);
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
  }

  async ngOnInit() {
    await this.getroomsList()
    await this.getUserData();
  }
  async getUserData() {
    try {
      const res = await this.apiservice.getUsers();
      this.allUserData = await res.data.data.filter((x: any) => x.id !== this.userDetails.id && x.role != 'superAdmin')
      this.isLoading = false
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }
  async getroomsList() {
    this.isLoading = true;
    try {
      const res = await this.apiservice.getRooms();
      this.roomsList = res.data.data;
      this.isLoading = false;
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;
      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }

  async assignRoomsToUser() {
    if (this.meetingType == '0') {
      this.toasterService.showWarning("Please select meeting type", "");
      return;
    }
    if (this.roomName == '0') {
      this.toasterService.showWarning("Please select meeting room", "");
      return;
    }

    if (!this.date) {
      this.toasterService.showWarning("Please select meeting date", "");
      return;
    }

    if (!this.startTime) {
      this.toasterService.showWarning("Please select meeting start time", "");
      return
    }

    if (!this.endTime) {
      this.toasterService.showWarning("Please select meeting end time", "");
      return
    }
    if (this.startTime > this.endTime) {
      this.toasterService.showWarning("Start time should be less than end time", "");
      return;
    }

    var startTime = new Date("1970-01-01T" + this.startTime + "Z");
    var endTime = new Date("1970-01-01T" + this.endTime + "Z");

    var timeDifference = endTime.getTime() - startTime.getTime();

    var hours = Math.floor(timeDifference / (1000 * 60 * 60));
    var minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));

    var result: any = hours + "." + minutes ;
    if (result > 2) {
      this.toasterService.showError("End time should not be greater than 2 hours from start time", "");
      return;
    }
    if (!this.purpose||this.purpose=='0') {
      this.toasterService.showWarning("Please select meeting purpose", "");
      return;
    }

    if(this.purpose == 'meeting'){
      if (!this.participant) {
        this.toasterService.showWarning("Please select meeting participant", "");
        return;
      }

      if(this.participant.length == 0){
        this.toasterService.showWarning("Please select meeting participant", "");
        return;
      }

      if((this.participant.length + 1) > this.seatingcapacity){
        this.toasterService.showWarning("Seating capacity for this meeting room is only "+this.seatingcapacity+" person", "");
        return;
      }
    }

    let param = {
      "roomId": this.roomName,
      "date": this.date,
      "startTime": this.startTime,
      "endTime": this.endTime,
      "meetingType": this.meetingType,
      "participant": JSON.stringify(this.participant)?JSON.stringify(this.participant):null,
      "purpose":this.purpose
    }
    this.isLoading = true;
    try {
      const res = await this.apiservice.assignRoom(param);
      this.isLoading = false;

      if (res.data.status) {
        this.toasterService.showSuccess(res.data.message, "");
        window.location.reload();
      }
    } catch (e: any) {
      this.toasterService.showError(e.response.data.message, "");
      this.isLoading = false;

      if (e.response.status == 401) {
        this.router.navigateByUrl('/login');
      }
    }
  }


  async getRoomData(id: any) {
    let roomData = this.roomsList.filter((x: any) => x.id == id)

    this.floor = roomData[0].floor;
    this.seatingcapacity = roomData[0].seatingcapacity;
    this.roomDetails = roomData[0].roomDetails;
  }

  async getRoomsByMeetingType(meetingType: any) {
    let room = this.roomsList.filter((x: any) => x.meetingType == meetingType || x.meetingType == "External/Internal") 
    this.roomsListData = room
  }



}
